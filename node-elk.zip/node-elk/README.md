# node-elk
logging in node.js using [winston](https://github.com/winstonjs/winston) and its [graylog2 extension](https://github.com/namshi/winston-graylog2) to quickly set up some logging in a node app using the ELK stack.


#create file
Type of files:
1-recursive file command
2-Non recursive command

General way(demo for top,works for every other)
 top -b > file.txt
Dump the file first then use Grep, b flag is for batch mode in linux system,Use appropriate batch flag in Mac Os

Mac Version:
top -o -pid -l 1 | grep "regex"

Alternative for recursive file command 
 top -n "int" -b > file.txt
 n flag stands for number of iterations,int can be integer depending on number of frames needed.b is the batch flag






